# Thema: Inseln unserer Entspannung

# Libraries

JQuery https://jquery.com/

MIDI.js https://github.com/mudcube/

# Inspiration

https://onlinesequencer.net/

# Songs

https://onlinesequencer.net/2654128 Für Elise 1/10

https://onlinesequencer.net/2665523 Deutschlandlied 4/10

https://onlinesequencer.net/2510323 Sand Storm 8/10

https://onlinesequencer.net/2664875 Bad Apple 10/10

# Temp Project host

https://minekid-lp.github.io/dumbschoolproject/

#

Playnote:

MIDI.noteOn(channelid: 0, note: 21, velocity: 1000, delay: 0);

Stopnote:

MIDI.noteOff(channelid: 0, note: 21, delay: 1);
